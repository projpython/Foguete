import interface_grafica as ig 

minha_interface = ig.Interface_Grafica()
